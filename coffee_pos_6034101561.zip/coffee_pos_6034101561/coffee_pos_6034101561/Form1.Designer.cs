﻿namespace coffee_pos_6034101561
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label5 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button40 = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.button44 = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.button41 = new System.Windows.Forms.Button();
            this.label22 = new System.Windows.Forms.Label();
            this.button29 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.label20 = new System.Windows.Forms.Label();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.label14 = new System.Windows.Forms.Label();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Payment = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label28 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.lb1 = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.Payment.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label5.Location = new System.Drawing.Point(540, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(158, 33);
            this.label5.TabIndex = 7;
            this.label5.Text = "Coffee Pos";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.Payment);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(25, 61);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(930, 484);
            this.tabControl1.TabIndex = 8;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.button40);
            this.tabPage1.Controls.Add(this.label24);
            this.tabPage1.Controls.Add(this.button44);
            this.tabPage1.Controls.Add(this.label23);
            this.tabPage1.Controls.Add(this.button41);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.button29);
            this.tabPage1.Controls.Add(this.button32);
            this.tabPage1.Controls.Add(this.button39);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.button36);
            this.tabPage1.Controls.Add(this.button37);
            this.tabPage1.Controls.Add(this.button38);
            this.tabPage1.Controls.Add(this.label20);
            this.tabPage1.Controls.Add(this.button33);
            this.tabPage1.Controls.Add(this.button34);
            this.tabPage1.Controls.Add(this.button35);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.button30);
            this.tabPage1.Controls.Add(this.button31);
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.button27);
            this.tabPage1.Controls.Add(this.button28);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.button24);
            this.tabPage1.Controls.Add(this.button25);
            this.tabPage1.Controls.Add(this.button26);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.button4);
            this.tabPage1.Controls.Add(this.button22);
            this.tabPage1.Controls.Add(this.button23);
            this.tabPage1.Controls.Add(this.button19);
            this.tabPage1.Controls.Add(this.button20);
            this.tabPage1.Controls.Add(this.button21);
            this.tabPage1.Controls.Add(this.button16);
            this.tabPage1.Controls.Add(this.button17);
            this.tabPage1.Controls.Add(this.button18);
            this.tabPage1.Controls.Add(this.button13);
            this.tabPage1.Controls.Add(this.button14);
            this.tabPage1.Controls.Add(this.button15);
            this.tabPage1.Controls.Add(this.button10);
            this.tabPage1.Controls.Add(this.button11);
            this.tabPage1.Controls.Add(this.button12);
            this.tabPage1.Controls.Add(this.button7);
            this.tabPage1.Controls.Add(this.button8);
            this.tabPage1.Controls.Add(this.button9);
            this.tabPage1.Controls.Add(this.button5);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.button2);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.label7);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 27);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(922, 453);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Menu";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button40
            // 
            this.button40.Location = new System.Drawing.Point(836, 154);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(69, 52);
            this.button40.TabIndex = 160;
            this.button40.Text = "25";
            this.button40.UseVisualStyleBackColor = true;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(705, 171);
            this.label24.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(121, 18);
            this.label24.TabIndex = 159;
            this.label24.Text = "Honey lime Soda";
            // 
            // button44
            // 
            this.button44.Location = new System.Drawing.Point(836, 96);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(69, 52);
            this.button44.TabIndex = 158;
            this.button44.Text = "25";
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(705, 113);
            this.label23.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(105, 18);
            this.label23.TabIndex = 157;
            this.label23.Text = "Red lime Soda";
            // 
            // button41
            // 
            this.button41.Location = new System.Drawing.Point(836, 38);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(69, 52);
            this.button41.TabIndex = 156;
            this.button41.Text = "25";
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(716, 55);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(84, 18);
            this.label22.TabIndex = 155;
            this.label22.Text = "Italian Soda";
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(611, 386);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(69, 52);
            this.button29.TabIndex = 154;
            this.button29.Text = "30";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(536, 386);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(69, 52);
            this.button32.TabIndex = 153;
            this.button32.Text = "25";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(461, 386);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(69, 52);
            this.button39.TabIndex = 152;
            this.button39.Text = "20";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(370, 403);
            this.label21.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(75, 18);
            this.label21.TabIndex = 151;
            this.label21.Text = "Nestcatea";
            // 
            // button36
            // 
            this.button36.Location = new System.Drawing.Point(611, 328);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(69, 52);
            this.button36.TabIndex = 150;
            this.button36.Text = "30";
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.Location = new System.Drawing.Point(536, 328);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(69, 52);
            this.button37.TabIndex = 149;
            this.button37.Text = "25";
            this.button37.UseVisualStyleBackColor = true;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.Location = new System.Drawing.Point(461, 328);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(69, 52);
            this.button38.TabIndex = 148;
            this.button38.Text = "20";
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(380, 345);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(63, 18);
            this.label20.TabIndex = 147;
            this.label20.Text = "Nescafa";
            // 
            // button33
            // 
            this.button33.Location = new System.Drawing.Point(611, 270);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(69, 52);
            this.button33.TabIndex = 146;
            this.button33.Text = "30";
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // button34
            // 
            this.button34.Location = new System.Drawing.Point(536, 270);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(69, 52);
            this.button34.TabIndex = 145;
            this.button34.Text = "25";
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.Location = new System.Drawing.Point(461, 270);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(69, 52);
            this.button35.TabIndex = 144;
            this.button35.Text = "20";
            this.button35.UseVisualStyleBackColor = true;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(392, 287);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(36, 18);
            this.label19.TabIndex = 143;
            this.label19.Text = "Milo";
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(611, 212);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(69, 52);
            this.button30.TabIndex = 142;
            this.button30.Text = "30";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(536, 212);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(69, 52);
            this.button31.TabIndex = 141;
            this.button31.Text = "25";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(370, 229);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(79, 18);
            this.label18.TabIndex = 140;
            this.label18.Text = "LemonTea";
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(611, 154);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(69, 52);
            this.button27.TabIndex = 139;
            this.button27.Text = "30";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(536, 154);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(69, 52);
            this.button28.TabIndex = 138;
            this.button28.Text = "25";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(380, 171);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 18);
            this.label14.TabIndex = 137;
            this.label14.Text = "MilkTea";
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(611, 96);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(69, 52);
            this.button24.TabIndex = 136;
            this.button24.Text = "30";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(536, 96);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(69, 52);
            this.button25.TabIndex = 135;
            this.button25.Text = "25";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(461, 96);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(69, 52);
            this.button26.TabIndex = 134;
            this.button26.Text = "20";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label15.Location = new System.Drawing.Point(612, 8);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 18);
            this.label15.TabIndex = 133;
            this.label15.Text = "Frappe";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label16.Location = new System.Drawing.Point(550, 8);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(27, 18);
            this.label16.TabIndex = 132;
            this.label16.Text = "Ice";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label17.Location = new System.Drawing.Point(475, 8);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(32, 18);
            this.label17.TabIndex = 131;
            this.label17.Text = "Hot";
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(611, 38);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(69, 52);
            this.button4.TabIndex = 130;
            this.button4.Text = "30";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(536, 38);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(69, 52);
            this.button22.TabIndex = 129;
            this.button22.Text = "25";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(461, 38);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(69, 52);
            this.button23.TabIndex = 128;
            this.button23.Text = "20";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(272, 386);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(69, 52);
            this.button19.TabIndex = 127;
            this.button19.Text = "30";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(197, 386);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(69, 52);
            this.button20.TabIndex = 126;
            this.button20.Text = "25";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(122, 386);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(69, 52);
            this.button21.TabIndex = 125;
            this.button21.Text = "20";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(272, 328);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(69, 52);
            this.button16.TabIndex = 124;
            this.button16.Text = "30";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(197, 328);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(69, 52);
            this.button17.TabIndex = 123;
            this.button17.Text = "25";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(122, 328);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(69, 52);
            this.button18.TabIndex = 122;
            this.button18.Text = "20";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(272, 270);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(69, 52);
            this.button13.TabIndex = 121;
            this.button13.Text = "50";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(197, 270);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(69, 52);
            this.button14.TabIndex = 120;
            this.button14.Text = "45";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(122, 270);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(69, 52);
            this.button15.TabIndex = 119;
            this.button15.Text = "35";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(272, 212);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(69, 52);
            this.button10.TabIndex = 118;
            this.button10.Text = "50";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(197, 212);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(69, 52);
            this.button11.TabIndex = 117;
            this.button11.Text = "45";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(122, 212);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(69, 52);
            this.button12.TabIndex = 116;
            this.button12.Text = "35";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(272, 154);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(69, 52);
            this.button7.TabIndex = 115;
            this.button7.Text = "50";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(197, 154);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(69, 52);
            this.button8.TabIndex = 114;
            this.button8.Text = "45";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(122, 154);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(69, 52);
            this.button9.TabIndex = 113;
            this.button9.Text = "35";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(197, 96);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(69, 52);
            this.button5.TabIndex = 112;
            this.button5.Text = "45";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(122, 96);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(69, 52);
            this.button6.TabIndex = 111;
            this.button6.Text = "35";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(272, 38);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(69, 52);
            this.button3.TabIndex = 110;
            this.button3.Text = "50";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(197, 38);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(69, 52);
            this.button2.TabIndex = 109;
            this.button2.Text = "45";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(392, 113);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 18);
            this.label13.TabIndex = 108;
            this.label13.Text = "Milk";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(380, 55);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(56, 18);
            this.label12.TabIndex = 107;
            this.label12.Text = "CoCoa";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(30, 403);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(61, 18);
            this.label11.TabIndex = 106;
            this.label11.Text = "ThaiTea";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(30, 345);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(74, 18);
            this.label10.TabIndex = 105;
            this.label10.Text = "GreenTea";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 287);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 18);
            this.label9.TabIndex = 104;
            this.label9.Text = "Cappuccino";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(30, 229);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(54, 18);
            this.label8.TabIndex = 103;
            this.label8.Text = "Mocha";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(44, 171);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(40, 18);
            this.label7.TabIndex = 102;
            this.label7.Text = "Latte";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(26, 113);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 18);
            this.label6.TabIndex = 101;
            this.label6.Text = "Americano";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(122, 38);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(69, 52);
            this.button1.TabIndex = 100;
            this.button1.Text = "35";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(26, 55);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(80, 18);
            this.label4.TabIndex = 99;
            this.label4.Text = "Esspresso";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label3.Location = new System.Drawing.Point(278, 8);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 18);
            this.label3.TabIndex = 98;
            this.label3.Text = "Frappe";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label2.Location = new System.Drawing.Point(216, 8);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 18);
            this.label2.TabIndex = 97;
            this.label2.Text = "Ice";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label1.Location = new System.Drawing.Point(141, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(32, 18);
            this.label1.TabIndex = 96;
            this.label1.Text = "Hot";
            // 
            // Payment
            // 
            this.Payment.Controls.Add(this.lb1);
            this.Payment.Location = new System.Drawing.Point(4, 27);
            this.Payment.Name = "Payment";
            this.Payment.Size = new System.Drawing.Size(922, 453);
            this.Payment.TabIndex = 2;
            this.Payment.Text = "Payment";
            this.Payment.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label28);
            this.tabPage2.Location = new System.Drawing.Point(4, 27);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(922, 453);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "About";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(27, 45);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(353, 54);
            this.label28.TabIndex = 0;
            this.label28.Text = "Author : Sasithon Pimmatha\r\n\r\nGitHub : https://github.com/sasithon2541/coffee_pos" +
    "";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(1040, 485);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(42, 18);
            this.label25.TabIndex = 10;
            this.label25.Text = "Price";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.Location = new System.Drawing.Point(975, 88);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(303, 384);
            this.listView1.TabIndex = 11;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Menu ";
            this.columnHeader1.Width = 175;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Price";
            this.columnHeader2.Width = 109;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(1124, 485);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(16, 18);
            this.label26.TabIndex = 12;
            this.label26.Text = "0";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(1194, 485);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(38, 18);
            this.label27.TabIndex = 13;
            this.label27.Text = "Bath";
            // 
            // button42
            // 
            this.button42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.button42.Location = new System.Drawing.Point(1146, 515);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(72, 30);
            this.button42.TabIndex = 14;
            this.button42.Text = "Clear";
            this.button42.UseVisualStyleBackColor = true;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.button43.Location = new System.Drawing.Point(1042, 515);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(72, 30);
            this.button43.TabIndex = 15;
            this.button43.Text = "Payment";
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // lb1
            // 
            this.lb1.Location = new System.Drawing.Point(24, 22);
            this.lb1.Multiline = true;
            this.lb1.Name = "lb1";
            this.lb1.ReadOnly = true;
            this.lb1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.lb1.Size = new System.Drawing.Size(878, 410);
            this.lb1.TabIndex = 0;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1306, 564);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label5);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.Payment.ResumeLayout(false);
            this.Payment.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.TabPage Payment;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox lb1;
    }
}

